
public class Bolme {
	
	public double bolme (double sayi1, double sayi2) {
		
		System.out.println("Sonuç = "+ (sayi1/sayi2));
		
		return sayi1 / sayi2;
	}

}
