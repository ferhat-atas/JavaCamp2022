
public class Carpma {
	
	
	public int carpma (int sayi1, int sayi2) {
		
		System.out.println("Sonuç = "+ (sayi1*sayi2));
		
		return sayi1*sayi2;
	}

}
