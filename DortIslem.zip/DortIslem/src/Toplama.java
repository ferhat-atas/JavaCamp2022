
public class Toplama {

	public int toplama(int sayi1, int sayi2) {

		System.out.println("Sonuç = " + (sayi1 + sayi2));

		return sayi1 + sayi2;
	}

	public int toplama(int sayi1, int sayi2, int sayi3) {

		System.out.println("Sonuç = " + (sayi1 + sayi2 + sayi3));

		return sayi1 + sayi2 + sayi3;
	}

	public int toplama(int sayi1, int sayi2, int sayi3, int sayi4) {
	
		
		return sayi1 + sayi2 + sayi3 + sayi4;

		
	}

	

}
